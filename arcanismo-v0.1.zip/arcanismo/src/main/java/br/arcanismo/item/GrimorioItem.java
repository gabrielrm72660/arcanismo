package br.arcanismo.item;

import java.util.Map;

import br.arcanismo.aspecto.Aspecto;
import br.arcanismo.conhecimento.Conhecimento;
import br.arcanismo.conhecimento.Pesquisa;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.level.Level;

/**
 * Grimório Arcano: o livro de pesquisas.
 *  - Clique direito: mostra conhecimento e pesquisas.
 *  - Agachado + clique direito: pesquisa a próxima disponível que você pode pagar.
 */
public class GrimorioItem extends Item {

    public GrimorioItem(Properties propriedades) {
        super(propriedades);
    }

    @Override
    public InteractionResult use(Level nivel, Player jogador, InteractionHand mao) {
        if (nivel.isClientSide()) return InteractionResult.SUCCESS;

        if (!Conhecimento.tem(jogador, Pesquisa.FUNDAMENTOS)) {
            Conhecimento.pesquisar(jogador, Pesquisa.FUNDAMENTOS);
            jogador.sendSystemMessage(Component.literal("Você abre o Grimório pela primeira vez...")
                    .withStyle(ChatFormatting.LIGHT_PURPLE, ChatFormatting.ITALIC));
            jogador.sendSystemMessage(Component.literal(Pesquisa.FUNDAMENTOS.descricao).withStyle(ChatFormatting.GRAY));
        }

        if (jogador.isShiftKeyDown()) {
            pesquisarProxima(jogador);
        } else {
            mostrar(jogador);
        }
        return InteractionResult.SUCCESS;
    }

    private static void pesquisarProxima(Player jogador) {
        for (Pesquisa p : Pesquisa.values()) {
            if (Conhecimento.disponivel(jogador, p) && Conhecimento.pesquisar(jogador, p)) {
                jogador.sendSystemMessage(Component.literal("✦ Pesquisa concluída: " + p.nome)
                        .withStyle(ChatFormatting.GOLD, ChatFormatting.BOLD));
                jogador.sendSystemMessage(Component.literal(p.descricao).withStyle(ChatFormatting.GRAY));
                jogador.level().playSound(null, jogador.blockPosition(),
                        SoundEvents.PLAYER_LEVELUP, SoundSource.PLAYERS, 0.8f, 1.2f);
                return;
            }
        }
        jogador.sendSystemMessage(Component.literal(
                "Conhecimento insuficiente. Escaneie mais coisas com a Lente Arcana.").withStyle(ChatFormatting.RED));
    }

    private static void mostrar(Player jogador) {
        jogador.sendSystemMessage(Component.literal("══ Grimório Arcano ══").withStyle(ChatFormatting.DARK_PURPLE, ChatFormatting.BOLD));

        MutableComponent pontos = Component.literal("Conhecimento: ").withStyle(ChatFormatting.GRAY);
        boolean algum = false;
        for (Aspecto a : Aspecto.values()) {
            int v = Conhecimento.pontos(jogador, a);
            if (v > 0) {
                pontos.append(a.texto().append(Component.literal(" " + v + "  ")));
                algum = true;
            }
        }
        if (!algum) pontos.append(Component.literal("nenhum ainda").withStyle(ChatFormatting.DARK_GRAY));
        jogador.sendSystemMessage(pontos);
        jogador.sendSystemMessage(Component.literal("Coisas escaneadas: " + Conhecimento.totalEscaneados(jogador))
                .withStyle(ChatFormatting.GRAY));

        for (Pesquisa p : Pesquisa.values()) {
            MutableComponent linha;
            if (Conhecimento.tem(jogador, p)) {
                linha = Component.literal("✔ " + p.nome).withStyle(ChatFormatting.GREEN);
            } else if (!Conhecimento.disponivel(jogador, p)) {
                linha = Component.literal("✖ " + p.nome + " (requer " + p.requisito.nome + ")")
                        .withStyle(ChatFormatting.DARK_GRAY);
            } else {
                linha = Component.literal("◇ " + p.nome + " — custo: ").withStyle(ChatFormatting.YELLOW);
                boolean primeiro = true;
                for (Map.Entry<Aspecto, Integer> e : p.custo.mapa().entrySet()) {
                    if (!primeiro) linha.append(Component.literal(", "));
                    linha.append(e.getKey().texto().append(Component.literal(" " + e.getValue())));
                    primeiro = false;
                }
            }
            jogador.sendSystemMessage(linha);
        }
        jogador.sendSystemMessage(Component.literal("Agache e clique para pesquisar a próxima.")
                .withStyle(ChatFormatting.DARK_GRAY, ChatFormatting.ITALIC));
    }
}
