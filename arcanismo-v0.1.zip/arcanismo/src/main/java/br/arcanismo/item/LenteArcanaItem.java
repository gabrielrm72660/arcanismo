package br.arcanismo.item;

import br.arcanismo.aspecto.ListaAspectos;
import br.arcanismo.aspecto.RegistroAspectos;
import br.arcanismo.conhecimento.Conhecimento;
import net.minecraft.ChatFormatting;
import net.minecraft.core.registries.BuiltInRegistries;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.Block;

/**
 * Lente Arcana: revela os aspectos do que você olha.
 *  - Clique com o botão direito num bloco ou numa criatura.
 *  - Ou segure um item na outra mão e clique no ar.
 * Cada coisa nova escaneada rende pontos de conhecimento.
 */
public class LenteArcanaItem extends Item {

    public LenteArcanaItem(Properties propriedades) {
        super(propriedades);
    }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level nivel = ctx.getLevel();
        Player jogador = ctx.getPlayer();
        if (jogador == null) return InteractionResult.PASS;
        if (nivel.isClientSide()) return InteractionResult.SUCCESS;

        Block bloco = nivel.getBlockState(ctx.getClickedPos()).getBlock();
        ItemStack comoItem = new ItemStack(bloco);
        String chave = "bloco:" + BuiltInRegistries.BLOCK.getKey(bloco);
        escanear(jogador, chave, bloco.getName(), RegistroAspectos.deItem(comoItem));
        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResult interactLivingEntity(ItemStack pilha, Player jogador, LivingEntity alvo, InteractionHand mao) {
        if (jogador.level().isClientSide()) return InteractionResult.SUCCESS;
        String chave = "entidade:" + BuiltInRegistries.ENTITY_TYPE.getKey(alvo.getType());
        escanear(jogador, chave, alvo.getName(), RegistroAspectos.deEntidade(alvo));
        return InteractionResult.SUCCESS;
    }

    @Override
    public InteractionResult use(Level nivel, Player jogador, InteractionHand mao) {
        InteractionHand outra = mao == InteractionHand.MAIN_HAND ? InteractionHand.OFF_HAND : InteractionHand.MAIN_HAND;
        ItemStack alvo = jogador.getItemInHand(outra);
        if (nivel.isClientSide()) return InteractionResult.SUCCESS;
        if (alvo.isEmpty()) {
            jogador.sendSystemMessage(Component.literal(
                    "Clique num bloco ou criatura, ou segure um item na outra mão.").withStyle(ChatFormatting.GRAY));
            return InteractionResult.SUCCESS;
        }
        String chave = "item:" + BuiltInRegistries.ITEM.getKey(alvo.getItem());
        escanear(jogador, chave, alvo.getHoverName(), RegistroAspectos.deItem(alvo));
        return InteractionResult.SUCCESS;
    }

    private static void escanear(Player jogador, String chave, Component nome, ListaAspectos aspectos) {
        if (aspectos.vazia()) {
            jogador.sendSystemMessage(Component.literal("Nada de arcano aqui.").withStyle(ChatFormatting.GRAY));
            return;
        }
        boolean novo = Conhecimento.registrarEscaneamento(jogador, chave, aspectos);

        jogador.sendSystemMessage(Component.empty()
                .append(nome.copy().withStyle(ChatFormatting.BOLD))
                .append(Component.literal(": "))
                .append(aspectos.texto()));

        if (novo) {
            jogador.sendSystemMessage(Component.literal("✦ Novo conhecimento adquirido! ✦")
                    .withStyle(ChatFormatting.LIGHT_PURPLE));
            jogador.level().playSound(null, jogador.blockPosition(),
                    SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.0f, 1.4f);
        }
    }
}
