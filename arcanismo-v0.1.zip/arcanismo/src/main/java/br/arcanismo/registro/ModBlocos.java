package br.arcanismo.registro;

import java.util.function.Function;
import java.util.function.Supplier;

import br.arcanismo.Arcanismo;
import br.arcanismo.bloco.CaldeiraoBlock;
import br.arcanismo.bloco.TerraCorrompidaBlock;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.item.BlockItem;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocos {
    public static final DeferredRegister<Block> BLOCOS = DeferredRegister.create(Registries.BLOCK, Arcanismo.MODID);

    public static final RegistryObject<Block> MINERIO_ARCANO = registrar("minerio_arcano", Block::new,
            () -> BlockBehaviour.Properties.of().mapColor(MapColor.STONE).strength(3.0f, 3.0f)
                    .requiresCorrectToolForDrops().sound(SoundType.STONE).lightLevel(s -> 4));

    public static final RegistryObject<Block> MINERIO_ARCANO_ARDOSIA = registrar("minerio_arcano_ardosia", Block::new,
            () -> BlockBehaviour.Properties.of().mapColor(MapColor.DEEPSLATE).strength(4.5f, 3.0f)
                    .requiresCorrectToolForDrops().sound(SoundType.DEEPSLATE).lightLevel(s -> 4));

    public static final RegistryObject<Block> CALDEIRAO_ARCANO = registrar("caldeirao_arcano", CaldeiraoBlock::new,
            () -> BlockBehaviour.Properties.ofFullCopy(Blocks.CAULDRON).noOcclusion());

    public static final RegistryObject<Block> TERRA_CORROMPIDA = registrar("terra_corrompida", TerraCorrompidaBlock::new,
            () -> BlockBehaviour.Properties.of().mapColor(MapColor.COLOR_PURPLE).strength(0.6f)
                    .sound(SoundType.GRAVEL).randomTicks());

    public static final RegistryObject<Block> TIJOLO_ARCANO = registrar("tijolo_arcano", Block::new,
            () -> BlockBehaviour.Properties.ofFullCopy(Blocks.STONE_BRICKS).mapColor(MapColor.COLOR_PURPLE));

    private ModBlocos() {}

    private static RegistryObject<Block> registrar(String nome, Function<BlockBehaviour.Properties, Block> fabrica,
                                                   Supplier<BlockBehaviour.Properties> propriedades) {
        RegistryObject<Block> bloco = BLOCOS.register(nome, () -> fabrica.apply(
                propriedades.get().setId(ResourceKey.create(Registries.BLOCK, Arcanismo.id(nome)))));
        ModItens.ITENS.register(nome, () -> new BlockItem(bloco.get(),
                ModItens.propriedades(nome).useBlockDescriptionPrefix()));
        return bloco;
    }
}
