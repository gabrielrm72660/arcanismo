package br.arcanismo.conhecimento;

import static br.arcanismo.aspecto.Aspecto.*;

import br.arcanismo.aspecto.ListaAspectos;

/**
 * Pesquisas do Grimório. Cada uma custa pontos de conhecimento de aspectos
 * (obtidos escaneando com a Lente Arcana) e pode exigir outra pesquisa antes.
 */
public enum Pesquisa {
    FUNDAMENTOS("fundamentos", "Fundamentos Arcanos",
            "Tudo é feito de aspectos. Escaneie o mundo com a Lente Arcana.",
            ListaAspectos.VAZIA, null),
    ALQUIMIA("alquimia", "Alquimia do Caldeirão",
            "Dissolva itens no Caldeirão Arcano aquecido e use catalisadores. Libera: Pó de Vis e Cristais refinados.",
            ListaAspectos.de(AGUA, 8, FOGO, 8), FUNDAMENTOS),
    CONJURACAO("conjuracao", "Conjuração Elemental",
            "Segure um cristal na outra mão para mudar o feitiço do Cajado.",
            ListaAspectos.de(FOGO, 10, AR, 10, MAGIA, 4), FUNDAMENTOS),
    METALURGIA("metalurgia", "Metalurgia Arcana",
            "Funda metal e magia no caldeirão. Libera: Lingote de Arcanita.",
            ListaAspectos.de(TERRA, 12, METAL, 6, ORDEM, 6), ALQUIMIA),
    PURIFICACAO("purificacao", "Purificação",
            "O Fluxo corrompe a terra. Libera: Sal Purificador.",
            ListaAspectos.de(ORDEM, 12, VIDA, 8), ALQUIMIA);

    public final String id;
    public final String nome;
    public final String descricao;
    public final ListaAspectos custo;
    public final Pesquisa requisito;

    Pesquisa(String id, String nome, String descricao, ListaAspectos custo, Pesquisa requisito) {
        this.id = id;
        this.nome = nome;
        this.descricao = descricao;
        this.custo = custo;
        this.requisito = requisito;
    }
}
