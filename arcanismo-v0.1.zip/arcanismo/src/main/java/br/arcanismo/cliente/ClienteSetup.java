package br.arcanismo.cliente;

import br.arcanismo.Arcanismo;
import net.minecraftforge.client.event.AddGuiOverlayLayersEvent;

/** Registros que só existem no cliente (telas e visores). */
public final class ClienteSetup {
    private ClienteSetup() {}

    public static void registrar() {
        AddGuiOverlayLayersEvent.BUS.addListener(evento ->
                evento.getLayeredDraw().add(Arcanismo.id("visor_lente"), (g, delta) -> LenteHud.desenhar(g)));
    }
}
