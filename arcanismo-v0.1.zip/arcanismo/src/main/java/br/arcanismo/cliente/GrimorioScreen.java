package br.arcanismo.cliente;

import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

import br.arcanismo.Arcanismo;
import br.arcanismo.aspecto.Aspecto;
import br.arcanismo.registro.ModBlocos;
import br.arcanismo.registro.ModItens;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.renderer.RenderPipelines;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.Identifier;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Items;
import net.minecraft.world.level.ItemLike;

/**
 * O Grimório Arcano ilustrado: um livro de duas páginas com aspectos,
 * pesquisas, receitas de crafting, receitas do caldeirão, feitiços e lugares.
 */
public class GrimorioScreen extends Screen {
    private static final Identifier TEXTURA = Arcanismo.id("textures/gui/grimorio.png");
    private static final int LARG = 256, ALT = 180;

    // Cores (ARGB)
    static final int TINTA = 0xFF3A2614;
    static final int TITULO = 0xFF5A1E78;
    static final int SUAVE = 0xFF7A6448;
    static final int DOURADO = 0xFF9A6A14;

    private final List<Pagina> paginas = new ArrayList<>();
    private int espalho = 0; // índice do par de páginas aberto
    private int esq, topo;
    private Button anterior, proxima;

    public GrimorioScreen() {
        super(Component.literal("Grimório Arcano"));
        montarPaginas();
    }

    // ------------------------------------------------------------------ estrutura

    @Override
    protected void init() {
        esq = (this.width - LARG) / 2;
        topo = (this.height - ALT) / 2 - 8;
        anterior = this.addRenderableWidget(Button.builder(Component.literal("◀ Anterior"), b -> virar(-1))
                .bounds(esq + 18, topo + ALT + 4, 80, 20).build());
        proxima = this.addRenderableWidget(Button.builder(Component.literal("Próxima ▶"), b -> virar(1))
                .bounds(esq + LARG - 98, topo + ALT + 4, 80, 20).build());
        this.addRenderableWidget(Button.builder(Component.literal("Índice"), b -> { espalho = 0; atualizarBotoes(); })
                .bounds(esq + LARG / 2 - 30, topo + ALT + 4, 60, 20).build());
        atualizarBotoes();
    }

    private int totalEspalhos() {
        return (paginas.size() + 1) / 2;
    }

    void irPara(int pagina) {
        espalho = Math.max(0, Math.min(totalEspalhos() - 1, pagina / 2));
        atualizarBotoes();
    }

    private void virar(int d) {
        espalho = Math.max(0, Math.min(totalEspalhos() - 1, espalho + d));
        atualizarBotoes();
    }

    private void atualizarBotoes() {
        if (anterior != null) anterior.active = espalho > 0;
        if (proxima != null) proxima.active = espalho < totalEspalhos() - 1;
    }

    @Override
    public boolean isPauseScreen() {
        return false;
    }

    @Override
    public void extractRenderState(GuiGraphicsExtractor g, int mouseX, int mouseY, float parcial) {
        g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, esq, topo, 0.0f, 0.0f, LARG, ALT, 256, 256);

        int i = espalho * 2;
        Pincel p = new Pincel(g, this.font, mouseX, mouseY);
        if (i < paginas.size()) {
            paginas.get(i).desenhar(p, esq + 18, topo + 16);
            p.centro(String.valueOf(i + 1), esq + 68, topo + 160, SUAVE);
        }
        if (i + 1 < paginas.size()) {
            paginas.get(i + 1).desenhar(p, esq + 137, topo + 16);
            p.centro(String.valueOf(i + 2), esq + 187, topo + 160, SUAVE);
        }
        super.extractRenderState(g, mouseX, mouseY, parcial);
    }

    // ------------------------------------------------------------------ desenho

    /** Pequeno ajudante de desenho: texto com quebra de linha, slots, itens e setas. */
    static final class Pincel {
        final GuiGraphicsExtractor g;
        final Font fonte;
        final int mx, my;
        static final int LARGURA = 102;

        Pincel(GuiGraphicsExtractor g, Font fonte, int mx, int my) {
            this.g = g;
            this.fonte = fonte;
            this.mx = mx;
            this.my = my;
        }

        /** Desenha o item e mostra a dica (nome) quando o mouse passa por cima. */
        void item(ItemStack item, int x, int y) {
            if (item.isEmpty()) return;
            g.item(item, x, y);
            if (mx >= x && mx < x + 16 && my >= y && my < y + 16) {
                g.setTooltipForNextFrame(fonte, item, mx, my);
            }
        }

        void texto(String s, int x, int y, int cor) {
            g.text(fonte, s, x, y, cor, false);
        }

        void centro(String s, int cx, int y, int cor) {
            g.text(fonte, s, cx - fonte.width(s) / 2, y, cor, false);
        }

        /** Título centralizado com divisor ornamental. Retorna o y seguinte. */
        int titulo(String s, int x, int y) {
            centro(s, x + LARGURA / 2, y, TITULO);
            g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, x + 1, y + 11, 0.0f, 222.0f, 100, 5, 256, 256);
            return y + 20;
        }

        /** Parágrafo com quebra automática. Retorna o y seguinte. */
        int paragrafo(String s, int x, int y, int cor) {
            for (String linha : quebrar(s, LARGURA)) {
                texto(linha, x, y, cor);
                y += 10;
            }
            return y + 3;
        }

        List<String> quebrar(String s, int largura) {
            List<String> linhas = new ArrayList<>();
            for (String bloco : s.split("\n")) {
                StringBuilder atual = new StringBuilder();
                for (String palavra : bloco.split(" ")) {
                    String teste = atual.length() == 0 ? palavra : atual + " " + palavra;
                    if (fonte.width(teste) > largura && atual.length() > 0) {
                        linhas.add(atual.toString());
                        atual = new StringBuilder(palavra);
                    } else {
                        atual = new StringBuilder(teste);
                    }
                }
                linhas.add(atual.toString());
            }
            return linhas;
        }

        void slot(int x, int y, ItemStack item) {
            g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, x, y, 0.0f, 192.0f, 18, 18, 256, 256);
            item(item, x + 1, y + 1);
        }

        void slotResultado(int x, int y, ItemStack item) {
            g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, x, y, 20.0f, 192.0f, 26, 26, 256, 256);
            item(item, x + 5, y + 5);
        }

        void seta(int x, int y) {
            g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, x, y, 48.0f, 192.0f, 22, 15, 256, 256);
        }

        void quadradoCor(int x, int y, int cor) {
            g.fill(x, y, x + 7, y + 7, 0xFF2A1A0A);
            g.fill(x + 1, y + 1, x + 6, y + 6, cor);
        }
    }

    static int corAspecto(Aspecto a) {
        return switch (a) {
            case AR -> 0xFFB8960A;
            case TERRA -> 0xFF2E7D1E;
            case FOGO -> 0xFFC4380E;
            case AGUA -> 0xFF1C6FB8;
            case ORDEM -> 0xFF6A7088;
            case ENTROPIA -> 0xFF3A2A48;
            case VIDA -> 0xFF3C9A2A;
            case METAL -> 0xFF5A5A5A;
            case ENERGIA -> 0xFFC07A08;
            case MAGIA -> 0xFF8A2AB8;
        };
    }

    // ------------------------------------------------------------------ tipos de página

    interface Pagina {
        void desenhar(Pincel p, int x, int y);
    }

    record PaginaTexto(String titulo, String texto) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo(titulo, x, y);
            p.paragrafo(texto, x, y, TINTA);
        }
    }

    /** Receita de bancada 3x3. Ingredientes nulos = espaço vazio. */
    record PaginaReceita(String titulo, List<Supplier<ItemStack>> grade, Supplier<ItemStack> resultado,
                         String texto) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo(titulo, x, y);
            for (int i = 0; i < 9; i++) {
                Supplier<ItemStack> s = i < grade.size() ? grade.get(i) : null;
                p.slot(x + (i % 3) * 18, y + (i / 3) * 18, s == null ? ItemStack.EMPTY : s.get());
            }
            p.seta(x + 57, y + 19);
            p.slotResultado(x + 78, y + 14, resultado.get());
            p.paragrafo(texto, x, y + 60, TINTA);
        }
    }

    /** Receita do Caldeirão Arcano. */
    record PaginaCaldeirao(String titulo, Supplier<ItemStack> catalisador, Object[] custo,
                           Supplier<ItemStack> resultado, String pesquisa, String texto) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo(titulo, x, y);
            p.slot(x + 4, y + 4, new ItemStack(ModBlocos.CALDEIRAO_ARCANO.get()));
            p.texto("+", x + 26, y + 9, SUAVE);
            p.slot(x + 34, y + 4, catalisador.get());
            p.seta(x + 56, y + 6);
            p.slotResultado(x + 78, y, resultado.get());
            y += 32;
            p.texto("Essência:", x, y, SUAVE);
            y += 10;
            for (int i = 0; i + 1 < custo.length; i += 2) {
                Aspecto a = (Aspecto) custo[i];
                p.quadradoCor(x + 2, y, corAspecto(a));
                p.texto(a.nome + " " + custo[i + 1], x + 12, y, corAspecto(a));
                y += 10;
            }
            p.texto("Pesquisa: " + pesquisa, x, y + 2, DOURADO);
            p.paragrafo(texto, x, y + 15, TINTA);
        }
    }

    record PaginaLista(String titulo, List<Supplier<ItemStack>> icones, List<String> nomes,
                       List<String> descricoes) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo(titulo, x, y);
            for (int i = 0; i < nomes.size(); i++) {
                ItemStack icone = icones.get(i).get();
                p.item(icone, x, y);
                p.texto(nomes.get(i), x + 20, y, TITULO);
                p.texto(descricoes.get(i), x + 20, y + 9, TINTA);
                y += 20;
            }
        }
    }

    record PaginaAspectos(String titulo, boolean primordiais) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo(titulo, x, y);
            for (Aspecto a : Aspecto.values()) {
                if (a.primordial() != primordiais) continue;
                p.quadradoCor(x, y + 1, corAspecto(a));
                p.texto(a.nome, x + 11, y, corAspecto(a));
                String detalhe = primordiais ? descricaoPrimordial(a) : a.componenteA.nome + " + " + a.componenteB.nome;
                p.texto(detalhe, x + 11, y + 9, SUAVE);
                y += 21;
            }
            if (!primordiais) {
                p.paragrafo("Escaneie com a Lente Arcana para descobrir de que aspectos cada coisa é feita.", x, y + 4, TINTA);
            }
        }

        static String descricaoPrimordial(Aspecto a) {
            return switch (a) {
                case AR -> "vento, voo, leveza";
                case TERRA -> "pedra, solo, firmeza";
                case FOGO -> "calor, chama, fúria";
                case AGUA -> "fluxo, cura, mar";
                case ORDEM -> "estrutura, cristal";
                case ENTROPIA -> "decadência, caos";
                default -> "";
            };
        }
    }

    record PaginaIndice(GrimorioScreen tela, List<String> secoes, List<Integer> numeros) implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            y = p.titulo("Índice", x, y);
            for (int i = 0; i < secoes.size(); i++) {
                String num = String.valueOf(numeros.get(i));
                p.texto(secoes.get(i), x + 2, y, TINTA);
                p.texto(num, x + Pincel.LARGURA - p.fonte.width(num), y, SUAVE);
                y += 12;
            }
        }
    }

    record PaginaCapa() implements Pagina {
        public void desenhar(Pincel p, int x, int y) {
            p.centro("✦ Grimório ✦", x + Pincel.LARGURA / 2, y + 6, TITULO);
            p.centro("Arcano", x + Pincel.LARGURA / 2, y + 18, TITULO);
            p.g.blit(RenderPipelines.GUI_TEXTURED, TEXTURA, x + 1, y + 32, 0.0f, 222.0f, 100, 5, 256, 256);
            p.slotResultado(x + 38, y + 38, new ItemStack(ModItens.GRIMORIO.get()));
            p.paragrafo("Tudo o que existe é feito de aspectos. Quem os compreende pode dobrar o mundo.", x, y + 68, TINTA);
            p.paragrafo("Agache e clique com o livro para pesquisar.", x, y + 122, SUAVE);
        }
    }

    // ------------------------------------------------------------------ conteúdo

    private static Supplier<ItemStack> i(Item item) {
        return () -> new ItemStack(item);
    }

    private static Supplier<ItemStack> m(Supplier<? extends ItemLike> item) {
        return () -> new ItemStack(item.get());
    }

    /** Qualquer cristal: alterna entre os seis a cada segundo. */
    private static Supplier<ItemStack> cristalQualquer() {
        Aspecto[] p = {Aspecto.AR, Aspecto.TERRA, Aspecto.FOGO, Aspecto.AGUA, Aspecto.ORDEM, Aspecto.ENTROPIA};
        return () -> new ItemStack(ModItens.cristal(p[(int) ((System.currentTimeMillis() / 1000) % p.length)]).get());
    }

    private static Supplier<ItemStack> cristal(Aspecto a) {
        return () -> new ItemStack(ModItens.cristal(a).get());
    }

    private void montarPaginas() {
        Supplier<ItemStack> C = cristalQualquer();
        List<String> secoes = List.of("Aspectos", "Conhecimento", "Bancada", "Caldeirão", "Feitiços", "Lugares");
        List<Integer> numeros = new ArrayList<>();

        paginas.add(new PaginaCapa());
        PaginaIndice indice = new PaginaIndice(this, secoes, numeros);
        paginas.add(indice);

        // Aspectos
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaAspectos("Primordiais", true));
        paginas.add(new PaginaAspectos("Compostos", false));

        // Conhecimento
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaTexto("A Lente Arcana",
                "Segure a Lente e clique num bloco ou criatura. Para um item, segure-o na outra mão e clique no ar.\n"
                        + "Cada coisa nova revela seus aspectos e dá pontos de conhecimento."));
        paginas.add(new PaginaTexto("Pesquisas",
                "Alquimia: Fogo 8, Água 8\n"
                        + "Conjuração: Ar 10, Fogo 10, Magia 4\n"
                        + "Metalurgia: Terra 12, Metal 6, Ordem 6\n"
                        + "Purificação: Ordem 12, Vida 8\n"
                        + "Agache e clique com o Grimório para pesquisar."));

        // Bancada
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaReceita("Grimório Arcano",
                List.of(i(Items.BOOK), C), m(ModItens.GRIMORIO),
                "Livro + qualquer cristal, sem forma definida."));
        paginas.add(new PaginaReceita("Lente Arcana",
                java.util.Arrays.asList(null, i(Items.GOLD_INGOT), null,
                        i(Items.GOLD_INGOT), i(Items.GLASS_PANE), i(Items.GOLD_INGOT),
                        null, C, null),
                m(ModItens.LENTE_ARCANA), "Revela os aspectos de tudo que você olha."));
        paginas.add(new PaginaReceita("Cajado de Aprendiz",
                java.util.Arrays.asList(null, null, C,
                        null, i(Items.STICK), null,
                        i(Items.GOLD_NUGGET), null, null),
                m(ModItens.CAJADO_APRENDIZ), "Guarda até 100 de Vis."));
        paginas.add(new PaginaReceita("Caldeirão Arcano",
                java.util.Arrays.asList(null, null, null,
                        C, null, C,
                        C, i(Items.CAULDRON), C),
                m(ModBlocos.CALDEIRAO_ARCANO), "Dissolve itens em essência pura."));
        paginas.add(new PaginaReceita("Tijolo Arcano",
                List.of(i(Items.STONE_BRICKS), i(Items.STONE_BRICKS), i(Items.STONE_BRICKS),
                        i(Items.STONE_BRICKS), i(Items.AMETHYST_SHARD), i(Items.STONE_BRICKS),
                        i(Items.STONE_BRICKS), i(Items.STONE_BRICKS), i(Items.STONE_BRICKS)),
                () -> new ItemStack(ModBlocos.TIJOLO_ARCANO.get(), 8), "Rende 8 tijolos para construir."));
        paginas.add(new PaginaReceita("Cajado de Arcanita",
                java.util.Arrays.asList(null, m(ModItens.LINGOTE_ARCANITA), C,
                        null, i(Items.BLAZE_ROD), m(ModItens.LINGOTE_ARCANITA),
                        i(Items.BLAZE_ROD), null, null),
                m(ModItens.CAJADO_ARCANITA), "Guarda até 300 de Vis."));

        // Caldeirão
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaTexto("O Caldeirão",
                "1. Encha com balde de água.\n2. Fogo, lava, magma ou fogueira embaixo.\n"
                        + "3. Jogue itens (Q): viram essência.\n4. Clique com o catalisador.\n"
                        + "Mão vazia mostra a essência. Acima de 100, o excesso vira Fluxo!"));
        paginas.add(new PaginaCaldeirao("Pó de Vis", i(Items.REDSTONE),
                new Object[]{Aspecto.ENERGIA, 6, Aspecto.MAGIA, 2}, () -> new ItemStack(ModItens.PO_DE_VIS.get(), 2),
                "Alquimia", "Recarrega 50 de Vis."));
        paginas.add(new PaginaCaldeirao("Cristal Refinado", i(Items.AMETHYST_SHARD),
                new Object[]{Aspecto.FOGO, 8}, cristal(Aspecto.FOGO),
                "Alquimia", "Vale para qualquer primordial: 8 dele geram o cristal."));
        paginas.add(new PaginaCaldeirao("Arcanita", i(Items.IRON_INGOT),
                new Object[]{Aspecto.METAL, 6, Aspecto.MAGIA, 4}, m(ModItens.LINGOTE_ARCANITA),
                "Metalurgia", "Metal impregnado de magia."));
        paginas.add(new PaginaCaldeirao("Sal Purificador", i(Items.SUGAR),
                new Object[]{Aspecto.ORDEM, 8, Aspecto.VIDA, 4}, () -> new ItemStack(ModItens.SAL_PURIFICADOR.get(), 4),
                "Purificação", "Limpa a Terra Corrompida."));
        paginas.add(new PaginaTexto("O Fluxo",
                "Essência desperdiçada vira Fluxo e corrompe a terra ao redor. A corrupção se espalha um pouco e enfraquece quem pisa nela.\n"
                        + "Use o Sal Purificador para curar o solo."));

        // Feitiços
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaLista("Feitiços",
                List.of(cristal(Aspecto.FOGO), cristal(Aspecto.AR), cristal(Aspecto.TERRA),
                        cristal(Aspecto.AGUA), cristal(Aspecto.ORDEM), cristal(Aspecto.ENTROPIA)),
                List.of("Fogo · 5 Vis", "Ar · 6 Vis", "Terra · 4 Vis", "Água · 8 Vis", "Ordem · 12 Vis", "Entropia · 10 Vis"),
                List.of("Bola de fogo", "Rajada de vento", "Escava um bloco", "Cura e apaga fogo", "Escudo protetor", "Murcha monstros")));
        paginas.add(new PaginaTexto("Vis",
                "Segure um cristal na outra mão para escolher o elemento. Sem cristal, o cajado lança fogo.\n"
                        + "Agache e clique para recarregar: Pó de Vis dá 50, um cristal dá 15.\n"
                        + "Outros elementos exigem a pesquisa Conjuração."));

        // Lugares
        numeros.add(paginas.size() + 1);
        paginas.add(new PaginaLista("Lugares Arcanos",
                List.of(m(ModBlocos.TIJOLO_ARCANO), m(ModBlocos.MINERIO_ARCANO_ARDOSIA), m(ModBlocos.TERRA_CORROMPIDA)),
                List.of("Vila dos Magos", "Cripta Arcana", "Torre Corrompida"),
                List.of("planícies, matas", "no subsolo", "pântanos, taigas")));
        paginas.add(new PaginaTexto("Minério Arcano",
                "Brilha fraco nas cavernas, entre as camadas -48 e 64. Ao ser minerado, liberta cristais de essência aleatórios.\n"
                        + "Os baús das masmorras guardam tesouros raros."));
    }
}
