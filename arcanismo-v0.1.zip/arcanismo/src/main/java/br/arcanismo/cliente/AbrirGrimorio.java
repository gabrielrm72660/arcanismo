package br.arcanismo.cliente;

import net.minecraft.client.Minecraft;

/** Só é chamado no cliente (nunca no servidor dedicado). */
public final class AbrirGrimorio {
    private AbrirGrimorio() {}

    public static void abrir() {
        Minecraft.getInstance().setScreen(new GrimorioScreen());
    }
}
